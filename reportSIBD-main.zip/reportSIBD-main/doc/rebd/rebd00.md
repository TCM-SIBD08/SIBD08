# Relatório de Especificação da Base de Dados

## Índice

:[Introdução](rebd01.md)  
:[Esquema conceptual](rebd02.md)  
:[Normalização](rebd03.md)  
:[Esquema Relacional](rebd04.md)  
:[SQL](rebd05.md)  

## Group _08_

Elementos de grupo

* Carlos Moreira [@CarlosMoreira36603](https://github.com/CarlosMoreira36603)
* António Moura [@antoniomoura98](https://github.com/antoniomoura98)
* Fábio Maia [@A036142](https://github.com/A036142)


---
_You can add a footer menu for navigation_ 
< Previous | [^ Main](https://github.com/exemploTrabalho/reportSIBD/) | [Next >](rebd01.md)
:--- | :---: | ---: 
