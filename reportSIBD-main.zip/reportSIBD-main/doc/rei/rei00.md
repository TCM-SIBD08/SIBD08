# Relatório de Especificação da Informação

## Índice

:[Introdução](rei01.md)  
:[Especificação de Requisitos](rei02.md)  
:[Esquema Conceptual](rei03.md)  

## Group _08_

Elementos de grupo

* Carlos Moreira [@CarlosMoreira36603](https://github.com/CarlosMoreira36603)
* António Moura [@antoniomoura98](https://github.com/antoniomoura98)
* Fábio Maia [@A036142](https://github.com/A036142)

---
_You can add a footer menu for navigation_ 
< Previous | [^ Main](https://github.com/exemploTrabalho/reportSIBD/) | [Next >](rei01.md)
:--- | :---: | ---: 
