# C1 : Introdução


## Descrição do trabalho
A nossa ideia passa por uma barbearia online. Onde existe a possibilidade de criar uma marcação definindo o dia, a hora, o profissional que deseja e o serviço (pode ser cortar cabelo, cortar barba, os dois, etc) e ainda ter acesso ao estado do serviço. Irão ser definidos os serviços, os produtos, os profissionais e a inscrição do cliente.  
O cliente terá de deixar o seu nome, morada, número de telemóvel ou telefone e NIF para poder ser identificado. Queremos abordar também o estado do serviço, se aquele cliente naquela hora está a ser atendido ou se ocorreu algum problema e teve de ser cancelada.


## Modelação do problema

_(Apresentar os pressupostos utilizados na modelação do problema, estes pressupostos poderão não estar na descrição do trabalho)_


---
[< Previous](rei00.md) | [^ Main](https://github.com/exemploTrabalho/reportSIBD/) | [Next >](rei02.md)
:--- | :---: | ---: 
