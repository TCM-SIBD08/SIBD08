# C2 : Especificação de Requisitos

Utilizador deste sistema é um Cliente que quererá marcar a sua ida ao Barbeiro onde terá de escolher:
- Identificação do Cliente (nome, morada, número de telemóvel ou telefone e NIF)
- O dia em que quer fazer a marcação;
- O horário da sua marcação;
- O profissional que pertende que lhe faça o serviço;
- Tipo de serviço que o cliente pertende (tipos de corte, barba e sobrancelha);
- Quantos clientes existem;
- Quantos profissionais é que existem;
- Quantas marcações existe para tal dia;
- Quantas marcações foram canceladas;
- Valor de faturação em determinado período do tempo;
- Valor do que não se faturou por marcações canceladas;
- Um cliente para um determinado dia;

O utilizador quando acede ao sistema para poder iniciar a sua marcação aquando da escolha do profissional e do dia  irá estar corrende de quais são as horas disponiveis.


---
[< Previous](rei01.md) | [^ Main](https://github.com/exemploTrabalho/reportSIBD/) | [Next >](rei03.md)
:--- | :---: | ---: 
